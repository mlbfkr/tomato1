package uz.fokus.taymer

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

object BlockPrefs {
    const val NAME = "fokus_block"
    val lock = Any()
}

/**
 * Fokus vaqtida tanlangan ilovalar ochilsa, uni yopib Fokus Taymerga qaytaradi.
 * Faqat "oyna almashdi" voqeasini tinglaydi, ekran mazmunini o'qimaydi, polling yo'q (batareya tejaydi).
 */
class BlockService : AccessibilityService() {

    private var csv = ""
    private var pkgSet: Set<String> = emptySet()
    private var lastHit = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) return

        val sp = getSharedPreferences(BlockPrefs.NAME, Context.MODE_PRIVATE)
        val until = sp.getLong("until", 0L)
        val now = System.currentTimeMillis()
        if (until <= now) return

        val c = sp.getString("pkgs", "") ?: ""
        if (c != csv) {
            csv = c
            pkgSet = if (c.isEmpty()) emptySet() else c.split(',').toHashSet()
        }
        if (!pkgSet.contains(pkg)) return
        if (now - lastHit < 700) return
        lastHit = now

        synchronized(BlockPrefs.lock) {
            sp.edit().putInt("hits", sp.getInt("hits", 0) + 1).apply()
        }
        performGlobalAction(GLOBAL_ACTION_HOME)
        try {
            val i = Intent(this, MainActivity::class.java)
            i.addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or
                    Intent.FLAG_ACTIVITY_SINGLE_TOP
            )
            startActivity(i)
        } catch (e: Exception) {
        }
        val left = ((until - now) / 60000).toInt() + 1
        Toast.makeText(this, "Fokus vaqti! Bu ilova bloklangan · $left daq qoldi", Toast.LENGTH_SHORT).show()
    }

    override fun onInterrupt() {}
}
