package uz.fokus.taymer

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlarmManager
import android.app.AlertDialog
import android.app.AppOpsManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.JsResult
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.content.ComponentName
import android.graphics.Color
import android.view.View
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.concurrent.Executors

// Kanal ID yangilandi: Android kanal ovozini keyin o'zgartirishga ruxsat bermaydi.
const val CHANNEL_ID = "fokus_alarm2"
const val NOTIF_ID = 1001

val VIBRATION_PATTERN = longArrayOf(0, 600, 300, 600, 300, 600)

fun alarmUri(): Uri {
    val a: Uri? = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
    if (a != null) return a
    return RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
}

fun alarmAttrs(): AudioAttributes =
    AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_ALARM)
        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
        .build()

fun createChannel(ctx: Context) {
    val ch = NotificationChannel(CHANNEL_ID, "Taymer signali", NotificationManager.IMPORTANCE_HIGH)
    ch.setSound(alarmUri(), alarmAttrs())
    ch.enableVibration(true)
    ch.vibrationPattern = VIBRATION_PATTERN
    ctx.getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
}

fun alarmIntent(ctx: Context, title: String, text: String): PendingIntent {
    val i = Intent(ctx, AlarmReceiver::class.java)
    i.putExtra("title", title)
    i.putExtra("text", text)
    return PendingIntent.getBroadcast(
        ctx, 1, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )
}

/** Ilova ochiq paytida signal: budilnik ovozi (alarm ovoz balandligida) + tebranish. */
object Ringer {
    private var mp: MediaPlayer? = null
    private val handler = Handler(Looper.getMainLooper())
    private val stopper = Runnable { stop() }

    fun start(ctx: Context) {
        stop()
        try {
            val p = MediaPlayer()
            p.setAudioAttributes(alarmAttrs())
            p.setDataSource(ctx.applicationContext, alarmUri())
            p.isLooping = true
            p.prepare()
            p.start()
            mp = p
            handler.postDelayed(stopper, 8000)
        } catch (e: Exception) {
            mp = null
        }
        vibrateNow(ctx)
    }

    fun stop() {
        handler.removeCallbacks(stopper)
        val p = mp
        mp = null
        if (p != null) {
            try { p.stop() } catch (e: Exception) { }
            try { p.release() } catch (e: Exception) { }
        }
    }

    @Suppress("DEPRECATION")
    private fun vibrateNow(ctx: Context) {
        try {
            val v = ctx.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            v.vibrate(VibrationEffect.createWaveform(VIBRATION_PATTERN, -1))
        } catch (e: Exception) { }
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        createChannel(ctx)
        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(ctx, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(intent.getStringExtra("title") ?: "Fokus Taymer")
            .setContentText(intent.getStringExtra("text") ?: "")
            .setCategory(Notification.CATEGORY_ALARM)
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        ctx.getSystemService(NotificationManager::class.java).notify(NOTIF_ID, n)
    }
}

class MainActivity : Activity() {

    private lateinit var web: WebView
    private val io = Executors.newSingleThreadExecutor()

    private fun js(code: String) {
        web.post { web.evaluateJavascript(code, null) }
    }

    private fun labelOf(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) {
        pkg.substringAfterLast('.')
    }

    private fun homePkg(): String? {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        return packageManager.resolveActivity(i, 0)?.activityInfo?.packageName
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createChannel(this)

        web = WebView(this)
        setContentView(web)

        val s = web.settings
        web.setBackgroundColor(Color.BLACK)
        web.overScrollMode = View.OVER_SCROLL_NEVER
        web.isVerticalScrollBarEnabled = false
        web.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        s.textZoom = 100
        s.setSupportZoom(false)
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = false

        web.webViewClient = WebViewClient()
        web.webChromeClient = object : WebChromeClient() {
            override fun onJsConfirm(
                view: WebView?, url: String?, message: String?, result: JsResult
            ): Boolean {
                AlertDialog.Builder(this@MainActivity)
                    .setMessage(message)
                    .setPositiveButton("OK") { _, _ -> result.confirm() }
                    .setNegativeButton("Bekor") { _, _ -> result.cancel() }
                    .setOnCancelListener { result.cancel() }
                    .show()
                return true
            }
        }
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("file:///android_asset/index.html")

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        web.evaluateJavascript("(window.__back&&window.__back())||false") { r ->
            if (r != "true") moveTaskToBack(true)
        }
    }

    override fun onPause() {
        super.onPause()
        web.evaluateJavascript("window.__nativeHide&&window.__nativeHide()", null)
    }

    override fun onResume() {
        super.onResume()
        // Ilovaga qaytilganda signal va bildirishnomani to'xtatamiz.
        Ringer.stop()
        getSystemService(NotificationManager::class.java).cancel(NOTIF_ID)
        web.evaluateJavascript("window.__nativeShow&&window.__nativeShow()", null)
    }

    inner class Bridge {

        @JavascriptInterface
        fun schedule(endMillis: Double, title: String, text: String) {
            val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val show = PendingIntent.getActivity(
                this@MainActivity, 0, Intent(this@MainActivity, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            am.setAlarmClock(
                AlarmManager.AlarmClockInfo(endMillis.toLong(), show),
                alarmIntent(this@MainActivity, title, text)
            )
        }

        @JavascriptInterface
        fun cancel() {
            val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.cancel(alarmIntent(this@MainActivity, "", ""))
        }

        /**
         * Taymer tugadi (HTML: Android.ring(T.end, sarlavha, matn)).
         * Rejalangan budilnikni olib tashlab, hoziroq chaladi.
         * Agar tugash vaqti 3 soniyadan ko'proq oldin bo'lgan bo'lsa (ilova orqada edi),
         * budilnik allaqachon bildirishnoma bilan chalingan — qayta chalmaymiz.
         */
        @JavascriptInterface
        fun ring(endMillis: Double, title: String, text: String) {
            val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.cancel(alarmIntent(this@MainActivity, "", ""))
            if (System.currentTimeMillis() - endMillis.toLong() > 3000) return
            runOnUiThread { Ringer.start(this@MainActivity) }
        }

        @JavascriptInterface
        fun stopRing() {
            runOnUiThread {
                Ringer.stop()
                getSystemService(NotificationManager::class.java).cancel(NOTIF_ID)
            }
        }

        @JavascriptInterface
        fun keepScreenOn(on: Boolean) {
            runOnUiThread {
                if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }

        @JavascriptInterface
        fun hasUsageAccess(): Boolean {
            val ops = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            val mode = ops.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName
            )
            return mode == AppOpsManager.MODE_ALLOWED
        }

        @JavascriptInterface
        fun openUsageSettings() {
            runOnUiThread { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
        }

        /** Boshqa ilovalarda o'tgan vaqt (soniya) va 5 soniyadan uzoq kirishlar soni, JSON ko'rinishida. */
        @JavascriptInterface
        fun otherAppsSeconds(fromMs: Double, toMs: Double): String {
            if (!hasUsageAccess()) return "{\"secs\":-1,\"n\":0}"
            val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val to = toMs.toLong()
            val ev = usm.queryEvents(fromMs.toLong(), to)
            val e = UsageEvents.Event()
            val started = HashMap<String, Long>()
            var total = 0L
            var n = 0

            fun close(st: Long, en: Long) {
                val d = en - st
                if (d > 0) {
                    total += d
                    if (d >= 5000) n++
                }
            }

            while (ev.hasNextEvent()) {
                ev.getNextEvent(e)
                val pkg: String = e.packageName ?: continue
                if (pkg == packageName) continue
                when (e.eventType) {
                    UsageEvents.Event.MOVE_TO_FOREGROUND -> started[pkg] = e.timeStamp
                    UsageEvents.Event.MOVE_TO_BACKGROUND -> {
                        val st = started.remove(pkg)
                        if (st != null) close(st, e.timeStamp)
                    }
                }
            }
            for (st in started.values) close(st, to)
            return "{\"secs\":${total / 1000},\"n\":$n}"
        }

        // ---------- Ilovalarni bloklash ----------
        @JavascriptInterface
        fun setBlock(untilMs: Double, pkgs: String) {
            getSharedPreferences(BlockPrefs.NAME, Context.MODE_PRIVATE).edit()
                .putLong("until", untilMs.toLong()).putString("pkgs", pkgs).apply()
        }

        @JavascriptInterface
        fun clearBlock() {
            getSharedPreferences(BlockPrefs.NAME, Context.MODE_PRIVATE).edit()
                .putLong("until", 0L).apply()
        }

        /** Oxirgi tekshiruvdan beri bloklangan urinishlar soni (o'qilgach nolga tushadi). */
        @JavascriptInterface
        fun takeBlockedHits(): Int {
            synchronized(BlockPrefs.lock) {
                val sp = getSharedPreferences(BlockPrefs.NAME, Context.MODE_PRIVATE)
                val h = sp.getInt("hits", 0)
                if (h > 0) sp.edit().putInt("hits", 0).apply()
                return h
            }
        }

        @JavascriptInterface
        fun isBlockerOn(): Boolean {
            val enabled = Settings.Secure.getString(
                contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            val cn = ComponentName(this@MainActivity, BlockService::class.java)
            val full = cn.flattenToString()
            val short = cn.flattenToShortString()
            return enabled.split(':').any { it.equals(full, true) || it.equals(short, true) }
        }

        @JavascriptInterface
        fun openAccessibilitySettings() {
            runOnUiThread { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }

        /** O'rnatilgan (ishga tushiriladigan) ilovalar ro'yxati; natija window.__appsCb(...) ga keladi. */
        @JavascriptInterface
        fun requestApps() {
            io.execute {
                try {
                    val pm = packageManager
                    val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                    val seen = HashSet<String>()
                    val items = ArrayList<Pair<String, String>>()
                    for (ri in pm.queryIntentActivities(q, 0)) {
                        val p = ri.activityInfo.packageName
                        if (p == packageName || !seen.add(p)) continue
                        items.add(Pair(p, ri.loadLabel(pm).toString()))
                    }
                    items.sortBy { it.second.lowercase() }
                    val arr = JSONArray()
                    for (a in items) arr.put(JSONObject().put("p", a.first).put("n", a.second))
                    js("window.__appsCb&&window.__appsCb(" + arr.toString() + ")")
                } catch (e: Exception) {
                    js("window.__appsCb&&window.__appsCb([])")
                }
            }
        }

        /**
         * Ilovalar sarfi: so'nggi [days] kun. Natija window.__usageCb({days:[daq...], top:[...], today:[...]}).
         * Fon oqimida hisoblanadi, interfeys qotmaydi.
         */
        @JavascriptInterface
        fun requestUsage(days: Int) {
            if (!hasUsageAccess()) {
                js("window.__usageCb&&window.__usageCb(null)")
                return
            }
            io.execute {
                try {
                    val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
                    val n = days.coerceIn(1, 14)
                    val home = homePkg()
                    val okCache = HashMap<String, Boolean>()
                    fun ok(p: String): Boolean = okCache.getOrPut(p) {
                        p != packageName && p != home && packageManager.getLaunchIntentForPackage(p) != null
                    }
                    val cal = Calendar.getInstance()
                    cal.set(Calendar.HOUR_OF_DAY, 0)
                    cal.set(Calendar.MINUTE, 0)
                    cal.set(Calendar.SECOND, 0)
                    cal.set(Calendar.MILLISECOND, 0)
                    val starts = LongArray(n)
                    for (i in n - 1 downTo 0) {
                        starts[i] = cal.timeInMillis
                        cal.add(Calendar.DAY_OF_YEAR, -1)
                    }
                    val now = System.currentTimeMillis()
                    val dayTotals = LongArray(n)
                    val week = HashMap<String, Long>()
                    val today = HashMap<String, Long>()
                    for (i in 0 until n) {
                        val end = if (i == n - 1) now else starts[i + 1]
                        val m = usm.queryAndAggregateUsageStats(starts[i], end)
                        var sum = 0L
                        for ((p, st) in m) {
                            val t = st.totalTimeInForeground
                            if (t <= 0L || !ok(p)) continue
                            sum += t
                            week[p] = (week[p] ?: 0L) + t
                            if (i == n - 1) today[p] = t
                        }
                        dayTotals[i] = minOf(sum, 86_400_000L)
                    }
                    fun top(mp: Map<String, Long>): JSONArray {
                        val arr = JSONArray()
                        for (e in mp.entries.sortedByDescending { it.value }.take(12)) {
                            arr.put(
                                JSONObject().put("p", e.key).put("n", labelOf(e.key)).put("s", e.value / 1000)
                            )
                        }
                        return arr
                    }
                    val out = JSONObject()
                    out.put("days", JSONArray(dayTotals.map { it / 60000 }))
                    out.put("top", top(week))
                    out.put("today", top(today))
                    js("window.__usageCb&&window.__usageCb(" + out.toString() + ")")
                } catch (e: Exception) {
                    js("window.__usageCb&&window.__usageCb(null)")
                }
            }
        }

        @JavascriptInterface
        fun shareText(text: String) {
            runOnUiThread {
                val i = Intent(Intent.ACTION_SEND)
                i.type = "text/plain"
                i.putExtra(Intent.EXTRA_TEXT, text)
                startActivity(Intent.createChooser(i, "Jurnalni yuborish"))
            }
        }
    }
}
